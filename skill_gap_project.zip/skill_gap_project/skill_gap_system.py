"""
=============================================================================
AI-Driven Skill Gap & Job Market Forecasting System
By: Shanmugakumar L  |  B.Tech AI & Data Science

Single-file, run-ready project.

HOW TO RUN:
    1. pip install fastapi uvicorn scikit-learn pandas numpy statsmodels joblib
    2. python skill_gap_system.py
    3. Open http://localhost:8000/docs

Optional (for Prophet forecasting):
    pip install prophet
=============================================================================
"""

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1 — IMPORTS
# ─────────────────────────────────────────────────────────────────────────────

import os
import re
import json
import warnings
import logging
import joblib
import numpy as np
import pandas as pd

from typing import List, Dict, Any, Optional
from pathlib import Path

warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2 — SKILL VOCABULARY & EXTRACTOR
# ─────────────────────────────────────────────────────────────────────────────

SKILL_VOCAB: List[str] = [
    "Python", "SQL", "Machine Learning", "Deep Learning", "TensorFlow", "PyTorch",
    "Scikit-learn", "XGBoost", "Random Forest", "NLP", "Computer Vision", "GenAI",
    "LangChain", "LangGraph", "RAG", "Prompt Engineering", "LLM Fine-tuning",
    "OpenAI API", "Hugging Face", "Vector DB", "ChromaDB", "Pinecone", "FastAPI",
    "Flask", "Docker", "Kubernetes", "AWS", "GCP", "Azure", "CI/CD", "MLOps",
    "Airflow", "MLflow", "REST API", "ETL", "Spark", "Kafka", "Pandas", "NumPy",
    "Matplotlib", "Seaborn", "Tableau", "Power BI", "Statistics",
    "Hypothesis Testing", "Time Series", "ARIMA", "Prophet", "N-BEATS", "LSTM",
]

SKILL_ALIASES: Dict[str, str] = {
    "py": "Python", "ml": "Machine Learning", "dl": "Deep Learning",
    "tf": "TensorFlow", "sklearn": "Scikit-learn", "scikit learn": "Scikit-learn",
    "xgb": "XGBoost", "rf": "Random Forest", "nlp": "NLP", "cv": "Computer Vision",
    "gen ai": "GenAI", "generative ai": "GenAI", "langchain": "LangChain",
    "langgraph": "LangGraph", "rag": "RAG", "retrieval augmented": "RAG",
    "prompt eng": "Prompt Engineering", "llm": "LLM Fine-tuning",
    "openai": "OpenAI API", "hf": "Hugging Face", "vector db": "Vector DB",
    "rest api": "REST API", "aws": "AWS", "gcp": "GCP", "mlops": "MLOps",
}

SKILL_VOCAB_LOWER = [s.lower() for s in SKILL_VOCAB]


class SkillExtractor:
    """Extract and normalise skills from free-form text."""

    def extract(self, text: str) -> List[str]:
        text_lower = text.lower()
        found = set()
        for idx, skill_lower in enumerate(SKILL_VOCAB_LOWER):
            pattern = r'\b' + re.escape(skill_lower) + r'\b'
            if re.search(pattern, text_lower):
                found.add(SKILL_VOCAB[idx])
        for alias, canonical in SKILL_ALIASES.items():
            if alias in text_lower and canonical in SKILL_VOCAB:
                found.add(canonical)
        return sorted(found)

    def from_pipe_string(self, skill_str: str) -> List[str]:
        return [s.strip() for s in skill_str.split("|") if s.strip()]


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3 — SEMANTIC MATCHING ENGINE
# ─────────────────────────────────────────────────────────────────────────────

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class SemanticMatcher:
    """Score a candidate profile against a job using Jaccard + TF-IDF cosine."""

    def __init__(self):
        self.vectorizer = TfidfVectorizer(
            max_features=500, stop_words="english", ngram_range=(1, 2)
        )
        self._fitted = False

    def _jaccard(self, a: List[str], b: List[str]) -> float:
        sa, sb = set(a), set(b)
        if not sa and not sb:
            return 0.0
        return len(sa & sb) / len(sa | sb)

    def _tfidf_cosine(self, text_a: str, text_b: str) -> float:
        try:
            if not self._fitted:
                self.vectorizer.fit([text_a, text_b])
                self._fitted = True
            vecs = self.vectorizer.transform([text_a, text_b]).toarray()
            return float(cosine_similarity(vecs[[0]], vecs[[1]])[0][0])
        except Exception:
            return 0.0

    def score(
        self,
        candidate_skills: List[str],
        candidate_text: str,
        job_skills: List[str],
        job_text: str,
    ) -> Dict[str, Any]:
        jaccard   = self._jaccard(candidate_skills, job_skills)
        cos       = self._tfidf_cosine(candidate_text, job_text)
        matched   = sorted(set(candidate_skills) & set(job_skills))
        missing   = sorted(set(job_skills) - set(candidate_skills))
        composite = round(0.5 * jaccard + 0.5 * cos, 4)
        return {
            "jaccard_score":   round(jaccard, 4),
            "cosine_score":    round(cos, 4),
            "composite_score": composite,
            "matched_skills":  matched,
            "missing_skills":  missing,
            "match_pct":       round(len(matched) / max(len(job_skills), 1) * 100, 1),
        }


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 4 — JOB READINESS ML MODEL
# ─────────────────────────────────────────────────────────────────────────────

from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, accuracy_score
from sklearn.pipeline import Pipeline

MODEL_PATH = "readiness_model.joblib"
LABEL_MAP  = {0: "Not Ready", 1: "Partially Ready", 2: "Ready"}


def _label_readiness(match_pct: float, exp_diff: int) -> int:
    if match_pct >= 60 and exp_diff >= 0:
        return 2
    elif match_pct >= 35 or exp_diff >= -1:
        return 1
    return 0


def _build_features(
    candidate_skills, job_skills, candidate_exp, job_min_exp, cgpa, certifications
) -> np.ndarray:
    match_pct = len(set(candidate_skills) & set(job_skills)) / max(len(job_skills), 1) * 100
    return np.array([[match_pct, candidate_exp - job_min_exp, cgpa,
                      certifications, len(candidate_skills)]])


def _train_readiness_model() -> Any:
    logger.info("Training job-readiness model …")
    np.random.seed(42)
    n = 2000
    rows = []
    for _ in range(n):
        mp  = np.random.uniform(0, 100)
        ed  = np.random.randint(-3, 8)
        cg  = np.random.uniform(5.5, 9.9)
        ct  = np.random.randint(0, 5)
        sc  = np.random.randint(3, 15)
        lbl = _label_readiness(mp, ed)
        rows.append([mp, ed, cg, ct, sc, lbl])

    df = pd.DataFrame(rows, columns=["mp","ed","cg","ct","sc","label"])
    X, y = df.drop("label", axis=1).values, df["label"].values
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    candidates = {
        "lr":  Pipeline([("s", StandardScaler()), ("m", LogisticRegression(max_iter=500, random_state=42))]),
        "rf":  Pipeline([("s", StandardScaler()), ("m", RandomForestClassifier(n_estimators=200, random_state=42))]),
        "gb":  Pipeline([("s", StandardScaler()), ("m", GradientBoostingClassifier(n_estimators=150, random_state=42))]),
    }

    best_model, best_f1 = None, 0.0
    for name, pipe in candidates.items():
        pipe.fit(X_tr, y_tr)
        f1 = f1_score(y_te, pipe.predict(X_te), average="weighted")
        logger.info("  %s → F1=%.4f", name, f1)
        if f1 > best_f1:
            best_f1, best_model = f1, pipe

    joblib.dump(best_model, MODEL_PATH)
    logger.info("✅ Best model saved (F1=%.4f)", best_f1)
    return best_model


def load_or_train_model():
    if os.path.exists(MODEL_PATH):
        logger.info("Loading saved model from %s", MODEL_PATH)
        return joblib.load(MODEL_PATH)
    return _train_readiness_model()


class ReadinessPredictor:
    def __init__(self):
        self.model = load_or_train_model()

    def predict(self, candidate_skills, job_skills, candidate_exp,
                job_min_exp, cgpa, certifications) -> Dict[str, Any]:
        X     = _build_features(candidate_skills, job_skills,
                                candidate_exp, job_min_exp, cgpa, certifications)
        label = int(self.model.predict(X)[0])
        proba = self.model.predict_proba(X)[0].tolist()
        return {
            "readiness_score": label,
            "readiness_label": LABEL_MAP[label],
            "confidence":      round(max(proba), 3),
            "probabilities": {
                "not_ready":       round(proba[0], 3),
                "partially_ready": round(proba[1], 3),
                "ready":           round(proba[2], 3),
            },
        }


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 5 — SKILL DEMAND FORECASTING (ARIMA + Prophet)
# ─────────────────────────────────────────────────────────────────────────────

def _make_synthetic_demand() -> pd.DataFrame:
    """Generate 24-month synthetic skill demand data."""
    months = pd.date_range("2023-01-01", periods=24, freq="MS")
    base   = {"Python": 280, "Machine Learning": 240, "LangChain": 80,
              "RAG": 60,    "FastAPI": 120,        "Docker": 100,
              "SQL": 200,   "Deep Learning": 160,  "Prompt Engineering": 50,
              "Hugging Face": 70}
    rows = []
    np.random.seed(42)
    for skill, b in base.items():
        for i, m in enumerate(months):
            trend  = b + i * np.random.uniform(2, 8)
            noise  = np.random.normal(0, b * 0.06)
            season = b * 0.08 * np.sin(2 * np.pi * i / 12)
            rows.append({"month": m, "skill": skill,
                         "demand_count": max(10, int(trend + noise + season))})
    return pd.DataFrame(rows)


def _arima_forecast(series: pd.Series, periods: int) -> Dict:
    from statsmodels.tsa.arima.model import ARIMA
    from statsmodels.tsa.stattools import adfuller
    try:
        d     = 0 if adfuller(series.dropna())[1] < 0.05 else 1
        train = series[:-3]
        test  = series[-3:]
        m     = ARIMA(train, order=(2, d, 2)).fit()
        pred  = m.forecast(3)
        mape  = float(np.mean(np.abs((test.values - pred) / (test.values + 1e-9))) * 100)
        mf    = ARIMA(series, order=(2, d, 2)).fit().forecast(periods)
        return {"model": "ARIMA", "forecast": [max(0, round(v)) for v in mf.tolist()], "mape": round(mape, 2)}
    except Exception as e:
        logger.warning("ARIMA failed: %s", e)
        return {"model": "ARIMA", "forecast": [int(series.mean())] * periods, "mape": 99.9}


def _prophet_forecast(series: pd.Series, periods: int) -> Dict:
    try:
        from prophet import Prophet
        df     = pd.DataFrame({"ds": series.index, "y": series.values})
        train  = df.iloc[:-3]; test = df.iloc[-3:]
        m      = Prophet(yearly_seasonality=True, weekly_seasonality=False,
                         daily_seasonality=False, interval_width=0.80)
        m.fit(train)
        fh     = m.make_future_dataframe(periods=3, freq="MS")
        ph     = m.predict(fh)["yhat"].values[-3:]
        mape   = float(np.mean(np.abs((test["y"].values - ph) / (test["y"].values + 1e-9))) * 100)
        mf     = Prophet(yearly_seasonality=True, weekly_seasonality=False, daily_seasonality=False)
        mf.fit(df)
        ff     = mf.make_future_dataframe(periods=periods, freq="MS")
        fc     = mf.predict(ff)["yhat"].values[-periods:].tolist()
        return {"model": "Prophet", "forecast": [max(0, round(v)) for v in fc], "mape": round(mape, 2)}
    except Exception as e:
        logger.warning("Prophet skipped: %s", e)
        return {"model": "Prophet", "forecast": [], "mape": 99.9}


class SkillDemandForecaster:
    def __init__(self):
        self.df     = _make_synthetic_demand()
        self.skills = sorted(self.df["skill"].unique().tolist())
        logger.info("Forecaster ready. Skills: %s", self.skills)

    def _series(self, skill: str) -> pd.Series:
        sub = self.df[self.df["skill"] == skill].sort_values("month")
        return sub.set_index("month")["demand_count"].asfreq("MS").fillna(method="ffill")

    def forecast(self, skill: str, periods: int = 3) -> Dict[str, Any]:
        if skill not in self.skills:
            return {"error": f"Skill '{skill}' not found. Available: {self.skills}"}
        series      = self._series(skill)
        arima_r     = _arima_forecast(series, periods)
        prophet_r   = _prophet_forecast(series, periods)
        best        = arima_r if arima_r["mape"] <= prophet_r["mape"] else prophet_r
        alt         = prophet_r if best["model"] == "ARIMA" else arima_r
        last_date   = series.index[-1]
        fut_months  = pd.date_range(last_date + pd.DateOffset(months=1), periods=periods, freq="MS")
        return {
            "skill":           skill,
            "periods":         periods,
            "best_model":      best["model"],
            "best_mape":       best["mape"],
            "forecast_months": [d.strftime("%Y-%m") for d in fut_months],
            "forecast_values": best["forecast"],
            "alt_model":       alt["model"],
            "alt_mape":        alt["mape"],
            "trend":           "rising" if best["forecast"] and best["forecast"][-1] > series.mean() else "falling",
        }

    def top_trending(self, top_n: int = 5) -> List[Dict]:
        results = []
        for skill in self.skills:
            try:
                s     = self._series(skill)
                slope = np.polyfit(range(len(s)), s.values, 1)[0]
                results.append({"skill": skill, "monthly_growth": round(float(slope), 2)})
            except Exception:
                pass
        return sorted(results, key=lambda x: x["monthly_growth"], reverse=True)[:top_n]


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 6 — FASTAPI APPLICATION
# ─────────────────────────────────────────────────────────────────────────────

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(
    title="🤖 AI-Driven Skill Gap & Job Market Forecasting API",
    description=(
        "**By Shanmugakumar L** — B.Tech AI & Data Science\n\n"
        "End-to-end NLP + ML pipeline:\n"
        "- 🔍 Skill extraction from raw text\n"
        "- 🤝 Semantic candidate-job matching (Jaccard + TF-IDF cosine)\n"
        "- 🎯 Job-readiness scoring (Random Forest / Gradient Boosting)\n"
        "- 📈 Skill demand forecasting (ARIMA + Prophet auto-select)\n"
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

# ── Singleton instances (loaded once at startup) ──────────────────────────────
extractor  = SkillExtractor()
matcher    = SemanticMatcher()
predictor  = ReadinessPredictor()
forecaster = SkillDemandForecaster()


# ── Request / Response schemas ────────────────────────────────────────────────

class TextInput(BaseModel):
    text: str = Field(
        ...,
        example="I know Python, LangChain, FastAPI, RAG pipelines, and Machine Learning.",
    )

class MatchRequest(BaseModel):
    candidate_skills: List[str] = Field(..., example=["Python", "LangChain", "FastAPI", "RAG"])
    candidate_text:   str       = Field(..., example="Experienced in Python, LangChain, FastAPI and RAG.")
    job_skills:       List[str] = Field(..., example=["Python", "LangChain", "Docker", "SQL"])
    job_text:         str       = Field(..., example="Looking for Python developer with LangChain and Docker.")

class ReadinessRequest(BaseModel):
    candidate_skills: List[str] = Field(..., example=["Python", "LangChain", "FastAPI"])
    job_skills:       List[str] = Field(..., example=["Python", "LangChain", "Docker", "SQL"])
    candidate_exp:    int       = Field(default=1, ge=0, example=1)
    job_min_exp:      int       = Field(default=2, ge=0, example=2)
    cgpa:             float     = Field(default=8.07, ge=0.0, le=10.0, example=8.07)
    certifications:   int       = Field(default=3, ge=0, example=3)

class FullAnalysisRequest(BaseModel):
    candidate_text:  str            = Field(..., example="I know Python, LangChain, FastAPI, RAG, and Machine Learning.")
    job_text:        str            = Field(..., example="Looking for Python developer with LangChain, RAG, Docker, SQL.")
    candidate_exp:   int            = Field(default=1, ge=0)
    job_min_exp:     int            = Field(default=2, ge=0)
    cgpa:            float          = Field(default=8.07, ge=0.0, le=10.0)
    certifications:  int            = Field(default=3, ge=0)
    forecast_skill:  Optional[str]  = Field(default="Python")
    forecast_months: int            = Field(default=3, ge=1, le=12)


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get("/", tags=["Health"])
def root():
    return {
        "status":  "✅ Running",
        "project": "AI-Driven Skill Gap & Job Market Forecasting System",
        "author":  "Shanmugakumar L",
        "docs":    "/docs",
        "endpoints": [
            "POST /extract-skills",
            "POST /match",
            "POST /readiness",
            "GET  /forecast/{skill}",
            "GET  /trending",
            "POST /full-analysis",
        ],
    }


@app.post("/extract-skills", tags=["1 - NLP"])
def extract_skills(body: TextInput):
    """Extract and normalise skills from any raw text."""
    skills = extractor.extract(body.text)
    return {
        "input_text":       body.text[:150],
        "extracted_skills": skills,
        "count":            len(skills),
    }


@app.post("/match", tags=["2 - Matching"])
def match(body: MatchRequest):
    """Score how well a candidate matches a job using Jaccard + TF-IDF cosine similarity."""
    return matcher.score(
        body.candidate_skills, body.candidate_text,
        body.job_skills,       body.job_text,
    )


@app.post("/readiness", tags=["3 - ML Scoring"])
def readiness(body: ReadinessRequest):
    """Predict job readiness label using ML (Random Forest / Gradient Boosting)."""
    return predictor.predict(
        body.candidate_skills, body.job_skills,
        body.candidate_exp,    body.job_min_exp,
        body.cgpa,             body.certifications,
    )


@app.get("/forecast/{skill}", tags=["4 - Forecasting"])
def forecast(skill: str, periods: int = 3):
    """Forecast monthly demand for a skill using ARIMA or Prophet (auto-selects best)."""
    if periods < 1 or periods > 12:
        raise HTTPException(400, "periods must be between 1 and 12.")
    result = forecaster.forecast(skill, periods)
    if "error" in result:
        raise HTTPException(404, result["error"])
    return result


@app.get("/trending", tags=["4 - Forecasting"])
def trending(top_n: int = 5):
    """Get top N fastest-growing skills by monthly demand growth rate."""
    return {"trending_skills": forecaster.top_trending(top_n)}


@app.post("/full-analysis", tags=["5 - Full Pipeline"])
def full_analysis(body: FullAnalysisRequest):
    """
    All-in-one pipeline:
    1. Extract skills from candidate + job text
    2. Semantic matching score
    3. Job-readiness prediction
    4. Skill demand forecast
    """
    cand_skills = extractor.extract(body.candidate_text)
    job_skills  = extractor.extract(body.job_text)

    match_result = matcher.score(
        cand_skills, body.candidate_text,
        job_skills,  body.job_text,
    )
    readiness_result = predictor.predict(
        cand_skills, job_skills,
        body.candidate_exp, body.job_min_exp,
        body.cgpa, body.certifications,
    )
    forecast_result = {}
    if body.forecast_skill:
        forecast_result = forecaster.forecast(body.forecast_skill, body.forecast_months)

    return {
        "pipeline": "AI-Driven Skill Gap & Job Market Forecasting",
        "author":   "Shanmugakumar L",
        "step_1_extracted": {
            "candidate_skills": cand_skills,
            "job_skills":       job_skills,
        },
        "step_2_match":     match_result,
        "step_3_readiness": readiness_result,
        "step_4_forecast":  forecast_result,
    }


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 7 — ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    print("""
╔══════════════════════════════════════════════════════════════╗
║   AI-Driven Skill Gap & Job Market Forecasting System        ║
║   By: Shanmugakumar L  |  B.Tech AI & Data Science           ║
╠══════════════════════════════════════════════════════════════╣
║   API Docs  →  http://localhost:8000/docs                    ║
║   Health    →  http://localhost:8000/                        ║
╠══════════════════════════════════════════════════════════════╣
║   Endpoints:                                                 ║
║   POST /extract-skills   — Extract skills from text          ║
║   POST /match            — Candidate ↔ Job matching score    ║
║   POST /readiness        — ML job-readiness prediction       ║
║   GET  /forecast/{skill} — ARIMA/Prophet demand forecast     ║
║   GET  /trending         — Top trending skills               ║
║   POST /full-analysis    — All-in-one pipeline               ║
╚══════════════════════════════════════════════════════════════╝
    """)

    uvicorn.run(app, host="0.0.0.0", port=8000)
